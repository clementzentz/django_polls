"""
django_polls est une application Django pour gérer des sondages.
"""

__version__ = "0.1.0"